package com.teamseven07.geosyncra_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeosyncraBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(GeosyncraBackendApplication.class, args);
    }

}
