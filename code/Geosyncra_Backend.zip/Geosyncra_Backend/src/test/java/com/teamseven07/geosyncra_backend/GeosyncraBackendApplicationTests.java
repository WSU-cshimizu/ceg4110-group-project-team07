package com.teamseven07.geosyncra_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeosyncraBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
