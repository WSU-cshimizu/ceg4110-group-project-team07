there is a server mentioned in the image controller change that accordig to the frontend if the live server has some other port use that
